# AtlasLootClassic [Core]

## [v1.1.3-beta](https://github.com/Hoizame/AtlasLootClassic/tree/v1.1.3-beta) (2019-08-12)
[Full Changelog](https://github.com/Hoizame/AtlasLootClassic/compare/v1.1.2-beta...v1.1.3-beta)

- update toc files  
- content phase item  
- add world epics  
- new enchanting border  
- add white border for items  
- fix locales file  
- release notes  
- test for cf import  
- add misc sets  
- add colors for player classes on sets  
- add content phase support for sets  
- toc deps update  
- add support for item set colors  
- fix display of version  
