local AtlasLoot = _G.AtlasLoot
local PvP = AtlasLoot.Button:AddExtraType("PvP")
local AL = AtlasLoot.Locales

function PvP.OnSet(mainButton, descFrame)

end
